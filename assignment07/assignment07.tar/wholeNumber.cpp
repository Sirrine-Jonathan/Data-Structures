/***********************************************************************
 * Implementation:
 *    WHOLENUMBER
 * Summary:
 *    
 * Author
 *   Spencer Eccles
 *   Jonathan Sirrine
 *   Atsushi Jindo
 *   Eric Brich
 **********************************************************************/
 #include "wholeNumber.h"